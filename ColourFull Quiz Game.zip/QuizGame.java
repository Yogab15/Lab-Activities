package Practice;

import java.util.Scanner;

public class QuizGame {
    private Question[] questions;
    private int score;
    private Scanner scanner;

    public QuizGame() {
        scanner = new Scanner(System.in);
        initializeQuestions();
        score = 0;
        startQuiz();
    }

    private void initializeQuestions() {
        questions = new Question[] {
            new Question("What is the capital of India?", new String[] {"1. Mumbai", "2. Hydrabad", "3. Delhi", "4. Paris"}, 3),
            new Question("Which planet is known as the Red Planet?", new String[] {"1. Earth", "2. Mars", "3. Jupiter", "4. Venus"}, 2),
            new Question("Who wrote 'Mrutyunjay'?", new String[] {"1. P.L. Deshpande", "2. Shivaji Savant", "3. Vishwas Patil", "4. Bahinabai Chaudhari"}, 2),
            new Question("Which is the State Animal of Maharashtra?", new String[] {"1. Tiger", "2. Lion", "3. Indian giant squirrel", "4. Panda"}, 3),
            new Question("What is the Financial capital of India?", new String[] {"1. Mumbai", "2. Nagpur", "3. Nagpur", "4. Pune"}, 1),
        };
    }

    private void startQuiz() {
        System.out.println(Color.PURPLE + "Welcome to the Quiz Game!" + Color.RESET);
        for (Question question : questions) {
            askQuestion(question);
        }
        displayFinalScore();
    }

    private void askQuestion(Question question) {
        System.out.println(Color.YELLOW + question.getQuestion() + Color.RESET);
        for (String option : question.getOptions()) {
            System.out.println(Color.CYAN + option + Color.RESET);
        }
        System.out.print(Color.BLUE + "Enter your answer (1-4): " + Color.RESET);
        int answer = scanner.nextInt();
        if (answer == question.getCorrectOption()) {
            System.out.println(Color.GREEN + "Correct!" + Color.RESET);
            score++;
        } else {
            System.out.println(Color.RED + "Incorrect! The correct answer was " + question.getCorrectOption() + "." + Color.RESET);
        }
    }

    private void displayFinalScore() {
        System.out.println(Color.PURPLE + "Quiz Over!" + Color.RESET);
        System.out.println(Color.BLACK + "Cogratulations!!!" + Color.RESET);
        System.out.println(Color.YELLOW + "Your final score is: " + Color.GREEN + score + "/" + questions.length + Color.RESET);
    }

    public static void main(String[] args) {
        new QuizGame();
    }
}
